var jose = require('jose');
// get the input from the request
session.input.readAsBuffer(function(readAsBufferError, jsonData) {
	if (readAsBufferError) {
		console.error('Error on readAsBuffer: ' + readAsBufferError);
	} else {
		try {
			debugger;
			// Create first JWS header that specifies signature algorithm
			// and 'Sam' signing private key
			var jwsHdr1 = jose.createJWSHeader('Sam-privkey', 'RS256');
			// Set a header parameter named 'kid' in the Protected Header
			jwsHdr1.setProtected('kid', 'Sam');
			// Create second JWS header that specifies signature algorithm
			// and 'Seth' signing private key
			var jwsHdr2 = jose.createJWSHeader('Seth-privkey', 'RS256');
			// Set a header parameter named 'kid' in the Protected Header
			jwsHdr2.setProtected('kid', 'Seth');
			// create JWSSigner object with 2 signers
			var mySigner = jose.createJWSSigner(jwsHdr1, jwsHdr2);
			// Update with the data to be signed
			mySigner.update(jsonData);
			// Execute the JWS sign action with JSON serialization
			mySigner.sign('json', function(error, jwsObj) {
				if (error) {
					// An error occurred during the encrypt process
					session.reject(error.errorMessage);
					return;
				} else {
					// Signing was successful
					console.debug('JSON-serialized object: ' + jwsObj);
					session.output.write(jwsObj);
				}
			});
		} catch (e) {
			session.reject("BuildMultiSignatureJWS.js error: " + e);
			return;
		}
	}
});
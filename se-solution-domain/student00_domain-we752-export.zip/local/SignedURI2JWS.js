// get URI
var sm = require('service-metadata');
var URI = sm.URI;
debugger;

// split URI at the question mark and place into array
var qs = URI.split('?');
var JWS = qs[1];
console.debug("JWS is:" + JWS );

// put result in context
session.output.write(JWS);
var hm = require ('header-metadata');
console.error('In GatewayScript code in HelloWorld')
session.output.write('<html><head><title>DataPower GatewayScript</title><body>Hello from DataPower via a GatewayScript action!</body></html>');

hm.response.set ('Content-Type', 'text/html');

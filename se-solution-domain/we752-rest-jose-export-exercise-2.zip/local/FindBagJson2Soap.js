// expected URI is /BaggageService/Bag?id=1589
console.debug("Starting FindBagJson2Soap");

// load needed optional modules and get references
var sm = require('service-metadata');
var querystring = require ('querystring');

// enable debugger capability
debugger;

// get incoming URI using dotted notation
var URI = sm.URI;

// split URI at the question mark and place into array
var qs = URI.split('?');

// get name-value pairs from query parm part s from incoming URI
var queryparms = querystring.parse(qs[1]);

var id = queryparms.id;

console.info("Received request to find bag: %s", id);

// Debug level is a stylesheet parameter which is configurable in GatewayScript action
// Check debug level , if debug level is above 5, will print request headers and service variables
// Default value is 0
if (!session.parameters.debugLevel) 
	session.parameters.debugLevel = 0;
if (session.parameters.debugLevel >= 5)
	{
		// print URI array elements
		console.debug("qs 0 = %s", qs[0]);
		console.debug("qs 1 = %s", qs[1]);

		//print current headers
		var hm = require('header-metadata');
		console.debug("Current headers %j", hm.current.headers);
		
		//print service variables
		console.debug("Input size is:" + sm.inputSize );
		console.debug("Inbound URL:" + sm.getVar('var://service/URL-in') );
		
		//print input JSON message
		console.debug("JSON Request is %s", queryparms);
	}
// construct SOAP request message
session.output.write(
	"<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" "
	+ "xmlns:fly=\"http://www.ibm.com/datapower/FLY/BaggageService/\">" 
	+ "<soapenv:Header/>"
	+ "<soapenv:Body>"
 	+ "<fly:BagInfoRequest>"
       	+ "<fly:id>" + id + "</fly:id>"
   	+ "</fly:BagInfoRequest>"
  	+ "</soapenv:Body>"
	+ "</soapenv:Envelope>"
	);

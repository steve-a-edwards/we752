var sm = require('service-metadata');
session.input.readAsBuffer(function(error, requestParms) {
	debugger;
	if (error)
		throw error;
	console.debug("requestParms: " + requestParms);
	sm.URI = "/BaggageService/Passenger/Bags?" + requestParms;
	console.debug("sm.URI: " + sm.URI);
});